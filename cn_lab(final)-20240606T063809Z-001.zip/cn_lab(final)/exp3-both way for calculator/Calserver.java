import java.io.*;
import java.net.*;
import java.util.*; 
public class Calserver {
public static void main(String args[]) throws IOException {
ServerSocket Serve = new ServerSocket(6666);
Socket sock = Serve.accept();
DataInputStream inpStrm = new DataInputStream(sock.getInputStream());
DataOutputStream outpStrm = new DataOutputStream(sock.getOutputStream());
Scanner sc = new Scanner(System.in);
try {
while (true) {
int oprtr = inpStrm.readInt();
System.out.println("Client has requested for " + oprtr + " operation");
int res = 0;
int data1 = sc.nextInt();
int data2 = sc.nextInt();
switch(oprtr) {
case 1 : 
res = data1 + data2;
outpStrm.writeUTF(Integer.toString(res));
break;
case 2 :
res = data1 - data2;
outpStrm.writeUTF(Integer.toString(res));
break;
case 3 :
res = data1 * data2;
outpStrm.writeUTF(Integer.toString(res));
break;
case 4 :
res = data1 / data2;
outpStrm.writeUTF(Integer.toString(res));
break;
default :
outpStrm.writeUTF(" You have given invalid choice! ");
break; 
}
System.out.println("Result sent to the client...");
}
}
catch(Exception exp) {
System.out.println(exp);
} 
}
}